function ce = cross_entropy(Y, Y_predicted)
    % your code here
