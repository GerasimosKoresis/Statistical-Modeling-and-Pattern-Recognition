clc;
close all;
clear all;

data25 = load('data_2_5.txt');

%first we initialize the vectors from the exercise
x1p = [3; 3; 5; 5];
x2p = [1; -1; 1; -1];
xp = transpose([x1p x2p]);

x1m = [1; 0; 0; -1];
x2m = [0; 1; -1; 0];
xm = transpose([x1m x2m]);

%now we plot them in space
plot(xp(1,:),xp(2,:),'bd','LineWidth',2)
hold on;
plot(xm(1,:),xm(2,:),'rd','LineWidth',2)
hold on;
grid on;

% line passing the x_+ outer element[1; 0]
ta = [-2:4];
y = 0*ta + 1;
plot(y,ta)

% on my opinion a good hyperplane
ta = [-2:4];
y = 0*ta + 2;
plot(y,ta)

% line passing the x_- outer elements [3;1],[3;-1]
ta = [-2:4];
y = 0*ta + 3;
plot(y,ta)


%first we initialize the vectors for the B part
x1bp = [2; 2; -2; -2];
x2bp = [2; -2; -2; 2];
xbp = transpose([x1bp x2bp]);

x1bm = [1; 1; -1; -1];
x2bm = [1; -1; -1; 1];
xbm = transpose([x1bm x2bm]);
%now we plot them in space
figure;
plot(xbp(1,:),xbp(2,:),'bd','LineWidth',2)
hold on;
plot(xbm(1,:),xbm(2,:),'rd','LineWidth',2)
hold on;
grid on;

x_normp = x1bp.^2 + x2bp.^2;
x_normp1 = transpose([x_normp,x_normp]);

x_normm = x1bm.^2 + x2bm.^2;
x_normm1 = transpose([x_normm,x_normm]);

phip = xbp - x_normp1 - 4;
phim = xbm - x_normm1 - 4;

figure;
plot(phip(1,:),phip(2,:),'bd','LineWidth',2)
hold on;
plot(phim(1,:),phim(2,:),'rd','LineWidth',2)
hold on;
grid on;

% line passing the x_+ outer element[-7; -7]
tb = [-9:-5];
y = -tb - 14;
plot(tb,y)

% on my opinion a good hyperplane
tb = [-12:-5];
y = -tb -17;
plot(tb,y)

% line passing the x_- outer element[-10; -10]
tb = [-14:-6];
y = -tb - 20;
plot(tb,y)
