clear all
close all

C = 1; % Choose C = 0.01, 0.1, 1, 10, 100, 1000, 10000

load('./twofeature2.txt');
n = size(twofeature2, 1); 
y = twofeature2(1:n, 1);
X = twofeature2(1:n, 2:3);

% Form the augmented dataset. 
%we need to add the third parameter of the vector
for i=1:n
    Xa(i,1) = X(i,1);
    Xa(i,2) = X(i,2);
    Xa(i,3) = X(i,1)^2 + X(i,2)^2;
end

Xpos = Xa(y==1, :); % positive examples
Xneg = Xa(y==-1, :); % negative examples

%  Visualize the example dataset
hold on
plot(Xpos(:, 1), Xpos(:, 2), 'b.');
plot(Xneg(:, 1), Xneg(:, 2), 'r.');
hold off
axis square;

% Form the matrices for the quadratic optimization. See the matlab manual for "quadprog"
H = zeros(n,n);
for i = 1:n
    for j=1:n
    K = Xa(i,:)*transpose(Xa(j,:));
    H(i,j) = (y(i)*y(j))*K;
    end
end
f = -ones(n,1);

A = [];

b = [];

Aeq = transpose(y);

beq = 0;

lambda = quadprog(H,f,A,b,Aeq,beq); % Find the Lagrange multipliers

indices = find(lambda > 0.0001); % Find the indices of the support vectors
Xsup = Xa(indices,:);% The support vectors only 
ysup = y(indices,:);  % The y coordinates for the support vectors
lambdasup = lambda(indices);

% Find the bias term w0
ww = ((lambda.*y)*ones(1,size(Xa,2))); % to fix the dimensions we multiply with ones(1,length(indices))
w = sum(ww.*Xa);
% % Find the bias term w0
% w0 = y(indices(1)) - sum((lambda.*y).*(Xa*Xa(indices(1),:)'));
% 
% % Find the weights
% w = sum(((lambda.*y)*ones(1,size(Xa,2))).*Xa);

wx = Xsup*transpose(w);
w0 = -(max(wx(ysup==-1)) + min(wx(ysup==1)))/2;

% Plot support vectors
Xsup_pos = Xsup(ysup==1, :);
Xsup_neg = Xsup(ysup==-1, :); 

hold on
plot(Xsup_pos(:, 1), Xsup_pos(:, 2), 'bo');
plot(Xsup_neg(:, 1), Xsup_neg(:, 2), 'ro');
hold off


% Plot decision boundary
hold on
for x1 = -1:0.01:1
    for x2 = -1:0.01:1
        temp = abs(w*[x1, x2,(x1^2 + x2^2)]' + w0);
        if ( temp < 0.01) % fill the 3rd coordinate
           plot(x1, x2, 'k.')
        end
    end
end
hold off


