clc;
clear all;
close all;

load('digits');
%A = reshape(train7(43, :), 28, 28)';
%imagesc(A);
%colorbar;

pixels = length(train0);
pics = size(train0,1);
%Propability of each feature for the digits of the according training set
pr = zeros(10, pixels);
for i = 1:pixels
    pr(1,i) = sum(train0(:,i));
    pr(2,i) = sum(train1(:,i));
    pr(3,i) = sum(train2(:,i));
    pr(4,i) = sum(train3(:,i));
    pr(5,i) = sum(train4(:,i));
    pr(6,i) = sum(train5(:,i));
    pr(7,i) = sum(train6(:,i));
    pr(8,i) = sum(train7(:,i));
    pr(9,i) = sum(train8(:,i));
    pr(10,i) = sum(train9(:,i));
end
pr=pr./pixels;
prpr = size(pr,1);
%We print every digit after we trained the models
for j = 1:10
    A = reshape(pr(j,:),28,28)';
    figure;
    imagesc(A);
    colorbar
end

%attempt to classify
confusion = zeros(10);
wrong_pred = 0;
% 
% lets start with the digit 0
for k =1:pics
    image = test0(k,:);
    max = 0; % to keep track of the max 
    wrong = 0;
    index = 0; %index for the confusion matrix later on
    for t = 1:prpr
        prob_true = pr(t,:).^image(1,:); %p_yi ^ x_i
        prob_false = (1-pr(t,:)).^(1-image(1,:)); %(1-p_yi)^1-x_i
        prob_given_x(t) = prod(prob_true.*prob_false); % TT(p_yi ^ x_i)(1-p_yi)^1-x_i
        if(max < prob_given_x(t))  %we update the max
            max = prob_given_x(t);
        else %we want the max to stay the same
            max = max;
        end
        if(max == prob_given_x(t)) %update of the index
            index = t;
        else %we dont change the index
            index = index;
        end
    end
    %(max == prob_given_x(t))
    wrong_pred = wrong_pred + (max ~= prob_given_x(1));
    
    confusion(1,index) = confusion(1,index) + 1;
end
%digit 1
for k =1:pics
    image = test1(k,:);
    max = 0; % to keep track of the max 
    wrong = 0;
    index = 0; %index for the confusion matrix later on
    for t = 1:prpr
        prob_true = pr(t,:).^image(1,:); %p_yi ^ x_i
        prob_false = (1-pr(t,:)).^(1-image(1,:)); %(1-p_yi)^1-x_i
        prob_given_x(t) = prod(prob_true.*prob_false); % TT(p_yi ^ x_i)(1-p_yi)^1-x_i
        if(max < prob_given_x(t))  %we update the max
            max = prob_given_x(t);
        else %we want the max to stay the same
            max = max;
        end
        if(max == prob_given_x(t)) %update of the index
            index = t;
        else %we dont change the index
            index = index;
        end
    end
    %(max == prob_given_x(t))
    wrong_pred = wrong_pred + (max ~= prob_given_x(2));
    
    confusion(2,index) = confusion(2,index) + 1;
end
%digit 2
for k =1:pics
    image = test2(k,:);
    max = 0; % to keep track of the max 
    wrong = 0;
    index = 0; %index for the confusion matrix later on
    for t = 1:prpr
        prob_true = pr(t,:).^image(1,:); %p_yi ^ x_i
        prob_false = (1-pr(t,:)).^(1-image(1,:)); %(1-p_yi)^1-x_i
        prob_given_x(t) = prod(prob_true.*prob_false); % TT(p_yi ^ x_i)(1-p_yi)^1-x_i
        if(max < prob_given_x(t))  %we update the max
            max = prob_given_x(t);
        else %we want the max to stay the same
            max = max;
        end
        if(max == prob_given_x(t)) %update of the index
            index = t;
        else %we dont change the index
            index = index;
        end
    end
    %(max == prob_given_x(t))
    wrong_pred = wrong_pred + (max ~= prob_given_x(3));
    
    confusion(3,index) = confusion(3,index) + 1;
end
%digit 3
for k =1:pics
    image = test3(k,:);
    max = 0; % to keep track of the max 
    wrong = 0;
    index = 0; %index for the confusion matrix later on
    for t = 1:prpr
        prob_true = pr(t,:).^image(1,:); %p_yi ^ x_i
        prob_false = (1-pr(t,:)).^(1-image(1,:)); %(1-p_yi)^1-x_i
        prob_given_x(t) = prod(prob_true.*prob_false); % TT(p_yi ^ x_i)(1-p_yi)^1-x_i
        if(max < prob_given_x(t))  %we update the max
            max = prob_given_x(t);
        else %we want the max to stay the same
            max = max;
        end
        if(max == prob_given_x(t)) %update of the index
            index = t;
        else %we dont change the index
            index = index;
        end
    end
    %(max == prob_given_x(t))
    wrong_pred = wrong_pred + (max ~= prob_given_x(4));
    
    confusion(4,index) = confusion(4,index) + 1;
end
%digit 4
for k =1:pics
    image = test4(k,:);
    max = 0; % to keep track of the max 
    wrong = 0;
    index = 0; %index for the confusion matrix later on
    for t = 1:prpr
        prob_true = pr(t,:).^image(1,:); %p_yi ^ x_i
        prob_false = (1-pr(t,:)).^(1-image(1,:)); %(1-p_yi)^1-x_i
        prob_given_x(t) = prod(prob_true.*prob_false); % TT(p_yi ^ x_i)(1-p_yi)^1-x_i
        if(max < prob_given_x(t))  %we update the max
            max = prob_given_x(t);
        else %we want the max to stay the same
            max = max;
        end
        if(max == prob_given_x(t)) %update of the index
            index = t;
        else %we dont change the index
            index = index;
        end
    end
    %(max == prob_given_x(t))
    wrong_pred = wrong_pred + (max ~= prob_given_x(5));
    
    confusion(5,index) = confusion(5,index) + 1;
end
%digit 5
for k =1:pics
    image = test5(k,:);
    max = 0; % to keep track of the max 
    wrong = 0;
    index = 0; %index for the confusion matrix later on
    for t = 1:prpr
        prob_true = pr(t,:).^image(1,:); %p_yi ^ x_i
        prob_false = (1-pr(t,:)).^(1-image(1,:)); %(1-p_yi)^1-x_i
        prob_given_x(t) = prod(prob_true.*prob_false); % TT(p_yi ^ x_i)(1-p_yi)^1-x_i
        if(max < prob_given_x(t))  %we update the max
            max = prob_given_x(t);
        else %we want the max to stay the same
            max = max;
        end
        if(max == prob_given_x(t)) %update of the index
            index = t;
        else %we dont change the index
            index = index;
        end
    end
    %(max == prob_given_x(t))
    wrong_pred = wrong_pred + (max ~= prob_given_x(6));
    
    confusion(6,index) = confusion(6,index) + 1;
end
%digit 6
for k =1:pics
    image = test6(k,:);
    max = 0; % to keep track of the max 
    wrong = 0;
    index = 0; %index for the confusion matrix later on
    for t = 1:prpr
        prob_true = pr(t,:).^image(1,:); %p_yi ^ x_i
        prob_false = (1-pr(t,:)).^(1-image(1,:)); %(1-p_yi)^1-x_i
        prob_given_x(t) = prod(prob_true.*prob_false); % TT(p_yi ^ x_i)(1-p_yi)^1-x_i
        if(max < prob_given_x(t))  %we update the max
            max = prob_given_x(t);
        else %we want the max to stay the same
            max = max;
        end
        if(max == prob_given_x(t)) %update of the index
            index = t;
        else %we dont change the index
            index = index;
        end
    end
    %(max == prob_given_x(t))
    wrong_pred = wrong_pred + (max ~= prob_given_x(7));
    
    confusion(7,index) = confusion(7,index) + 1;
end
%digit 7
for k =1:pics
    image = test7(k,:);
    max = 0; % to keep track of the max 
    wrong = 0;
    index = 0; %index for the confusion matrix later on
    for t = 1:prpr
        prob_true = pr(t,:).^image(1,:); %p_yi ^ x_i
        prob_false = (1-pr(t,:)).^(1-image(1,:)); %(1-p_yi)^1-x_i
        prob_given_x(t) = prod(prob_true.*prob_false); % TT(p_yi ^ x_i)(1-p_yi)^1-x_i
        if(max < prob_given_x(t))  %we update the max
            max = prob_given_x(t);
        else %we want the max to stay the same
            max = max;
        end
        if(max == prob_given_x(t)) %update of the index
            index = t;
        else %we dont change the index
            index = index;
        end
    end
    %(max == prob_given_x(t))
    wrong_pred = wrong_pred + (max ~= prob_given_x(8));
    
    confusion(8,index) = confusion(8,index) + 1;
end
%digit 8
for k =1:pics
    image = test8(k,:);
    max = 0; % to keep track of the max 
    wrong = 0;
    index = 0; %index for the confusion matrix later on
    for t = 1:prpr
        prob_true = pr(t,:).^image(1,:); %p_yi ^ x_i
        prob_false = (1-pr(t,:)).^(1-image(1,:)); %(1-p_yi)^1-x_i
        prob_given_x(t) = prod(prob_true.*prob_false); % TT(p_yi ^ x_i)(1-p_yi)^1-x_i
        if(max < prob_given_x(t))  %we update the max
            max = prob_given_x(t);
        else %we want the max to stay the same
            max = max;
        end
        if(max == prob_given_x(t)) %update of the index
            index = t;
        else %we dont change the index
            index = index;
        end
    end
    %(max == prob_given_x(t))
    wrong_pred = wrong_pred + (max ~= prob_given_x(9));
    
    confusion(9,index) = confusion(9,index) + 1;
end
%digit 9
for k =1:pics
    image = test9(k,:);
    max = 0; % to keep track of the max 
    wrong = 0;
    index = 0; %index for the confusion matrix later on
    for t = 1:prpr
        prob_true = pr(t,:).^image(1,:); %p_yi ^ x_i
        prob_false = (1-pr(t,:)).^(1-image(1,:)); %(1-p_yi)^1-x_i
        prob_given_x(t) = prod(prob_true.*prob_false); % TT(p_yi ^ x_i)(1-p_yi)^1-x_i
        if(max < prob_given_x(t))  %we update the max
            max = prob_given_x(t);
        else %we want the max to stay the same
            max = max;
        end
        if(max == prob_given_x(t)) %update of the index
            index = t;
        else %we dont change the index
            index = index;
        end
    end
    %(max == prob_given_x(t))
    wrong_pred = wrong_pred + (max ~= prob_given_x(10));
    
    confusion(10,index) = confusion(10,index) + 1;
end

% confusion = zeros(10);
% confusion(1,:) = conf(test0,pr);
% confusion(2,:) = conf(test1,pr);
% confusion(3,:) = conf(test2,pr);
% confusion(4,:) = conf(test3,pr);
% confusion(5,:) = conf(test4,pr);
% confusion(6,:) = conf(test5,pr);
% confusion(7,:) = conf(test6,pr);
% confusion(8,:) = conf(test7,pr);
% confusion(9,:) = conf(test8,pr);
% confusion(10,:) = conf(test9,pr);

fullset = pics*10;
accuracy = (fullset - wrong_pred)/fullset
con = confusion./pics; % in order to get a form of percentage
diagonal = transpose(diag(con));
