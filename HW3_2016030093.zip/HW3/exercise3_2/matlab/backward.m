function [d_CE_d_W, d_CE_d_b] = backward(X, Y, Y_predicted)
    % your code here

