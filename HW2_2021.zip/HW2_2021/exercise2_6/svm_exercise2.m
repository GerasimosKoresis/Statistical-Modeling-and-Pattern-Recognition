clear all
close all

C = 10000; % Choose C = 0.01, 0.1, 1, 10, 100, 1000, 10000

load('./twofeature1.txt');
n = size(twofeature1, 1); % leave out the last example
y = twofeature1(1:n, 1);
X = twofeature1(1:n, 2:3);

Xpos = X(y==1, :); % positive examples
Xneg = X(y==-1, :); % negative examples

%  Visualize the example dataset
hold on
plot(Xpos(:, 1), Xpos(:, 2), 'b.');
plot(Xneg(:, 1), Xneg(:, 2), 'r.');
hold off
axis square;

% Form the matrices for the quadratic optimization. See the matlab manual for "quadprog"
H = zeros(n,n);
for i = 1:n
    for j=1:n
    K = X(i,:)*transpose(X(j,:));
    H(i,j) = (y(i)*y(j))*K;
    end
end

f = -ones(1,n);

A = ones(1,n);

b = C;

Aeq = transpose(y);

beq = 0;

lambda = quadprog(H,f,A,b,Aeq,beq); % Find the Lagrange multipliers

indices = find(lambda > 0.0001 & C >= lambda); % Find the support vectors
Xsup = X(indices,:);% The support vectors only 
ysup = y(indices,:);  % The y coordinates for the support vectors
lambdasup = lambda(indices); % the lagrange multipliers

% Find the bias term w0
% Find the weights
ww = ((lambdasup.*ysup)*ones(1,length(indices))); % to fix the dimensions we multiply with ones(1,length(indices))
w = transpose(sum(ww*Xsup));

wx_plus = Xsup(ysup==1,:)*(w);
wx_minus = Xsup(ysup==-1,:)*(w);
w0 = -(max(wx_minus) + min(wx_plus))/2;
% Plot support vectors
Xsup_pos = Xsup(ysup==1, :);
Xsup_neg = Xsup(ysup==-1, :);

hold on
plot(Xsup_pos(:, 1), Xsup_pos(:, 2), 'bo');
plot(Xsup_neg(:, 1), Xsup_neg(:, 2), 'ro');
hold on


% Find the width of the margin
denom = sqrt(transpose(w)*w);
width = 2/denom;

% Plot decision boundary
x1 = linspace(0.5, 4.5, 100);
x2 = -(w(1,1)*x1 + w0)/w(2,1);
hold on
plot(x1, x2, 'k')
hold on
plot(x1,x2-1,'b')  %Plot the Margin of class +1
plot(x1,x2+1,'r')  %Plot the Margin of class -1
hold off

