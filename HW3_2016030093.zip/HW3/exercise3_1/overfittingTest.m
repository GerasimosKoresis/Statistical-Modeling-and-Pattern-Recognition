% overfittingTest.m
clear all;
close all;
clc;

numFeatures = 1000;
numSelectedFeatures = 100;
numPositiveExamples = 15;  % E.g., Autism
numNegativeExamples = 10;  % E.g., Typically developing subjects
numExamples = numPositiveExamples + numNegativeExamples;
labels = ones(numExamples, 1);
labels(1:numNegativeExamples) = -1;
features = randn(numExamples, numFeatures);

disp('Classify without feature selection')
% Cross validation. Leave one out
numCorrectlyClassified = 0;
for i = 1:numExamples
    idx = [1:i-1, i+1:numExamples]; % Leave out example i 
    SVMStruct = fitcsvm(features(idx, :), labels(idx));
    predictedLabel = predict(SVMStruct, features(i, :)); % Classify example i
    if (predictedLabel == labels(i))
        numCorrectlyClassified = numCorrectlyClassified + 1;
    end
end

% Proportion of true results (both true positives and true negatives) among the total number of cases examined
accuracy = numCorrectlyClassified/numExamples;  
disp(strcat('accuracy : ', num2str(accuracy)))
disp(' ')

% --------------------------------------------------------------------

disp('Classify with feature selection inside the cross validation')

% Cross validation. Leave one out
numCorrectlyClassified = 0;
for i = 1:numExamples
    % Your code here   
    index = [1:i-1, i+1:numExamples]; %in that way we leave one out as requested
    temp = zeros(numFeatures,1); %for the featured selection we will do later
    
    for j = 1:numFeatures
        temp(j) = similarityMeasure(features(index,j), labels(index));
    end
    [rSorted, sortedFeatureIndices] = sort(temp, 'descend');
    % The indices of the selected features.
    selectedIndices = sortedFeatureIndices(1:numSelectedFeatures);
    
    svmunit = fitcsvm(features(index,selectedIndices),labels(index));
    prediction = predict(svmunit,features(i,selectedIndices));
    
    if(prediction == labels(i))
        numCorrectlyClassified = numCorrectlyClassified + 1;
    end
    
end

% Proportion of true results (both true positives and true negatives) among the total number of cases examined
accuracy = numCorrectlyClassified/numExamples;  
disp(strcat('accuracy : ', num2str(accuracy)))
disp(' ')

% --------------------------------------------------------------------

disp('Classify with feature selection outside the cross validation')
% Feature selection
% Your code here
temp = zeros(numFeatures,1); %for the featured selection we will do later
    
for j = 1:numFeatures
    temp(j) = similarityMeasure(features(:,j), labels);
end
[rSorted, sortedFeatureIndices] = sort(temp, 'descend');
% The indices of the selected features.
selectedIndices = sortedFeatureIndices(1:numSelectedFeatures);

% Cross validation. Leave one out
numCorrectlyClassified = 0;
for i = 1:numExamples
    % Your code here
    index = [1:i-1, i+1:numExamples]; %in that way we leave one out as requested
    
    svmunit = fitcsvm(features(index,selectedIndices),labels(index));
    prediction = predict(svmunit,features(i,selectedIndices));
    
    if(prediction == labels(i))
        numCorrectlyClassified = numCorrectlyClassified + 1;
    end
    
end

% Proportion of true results (both true positives and true negatives) among the total number of cases examined
accuracy = numCorrectlyClassified/numExamples;  
disp(strcat('accuracy : ', num2str(accuracy)))
disp(' ')
