function r = sigmoid(z)
    % your code here
