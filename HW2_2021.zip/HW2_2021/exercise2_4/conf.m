function conrow = conf(testset,pr)

conrow = [0 0 0 0 0 0 0 0 0 0];
wrong_pred = 0;

%lets start with the digit 0
for k =1:500
    image = testset(k,:);
    max = 0; % to keep track of the max 
    wrong = 0;
    index = 0; %index for the confusion matrix later on
    for t = 1:10
        prob_true = pr(t,:).^image(1,:); %p_yi ^ x_i
        prob_false = (1-pr(t,:)).^(1-image(1,:)); %(1-p_yi)^1-x_i
        prob_given_x(t) = prod(prob_true.*prob_false); % TT(p_yi ^ x_i)(1-p_yi)^1-x_i
        if(max < prob_given_x(t))  %we update the max
            max = prob_given_x(t);
        else %we want the max to stay the same
            max = max;
        end
        if(max == prob_given_x(t)) %update of the index
            index = t;
        else %we dont change the index
            index = index;
        end
    end
    %(max == prob_given_x(t))
    %wrong = max ~= prob_given_x(digit+1);
    %wrong_pred = wrong_pred + wrong;
    
    conrow(index) = conrow(index) + 1;
end

end